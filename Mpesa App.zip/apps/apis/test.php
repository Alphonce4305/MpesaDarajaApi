<?php
require 'functions.php';
echo generateToken();