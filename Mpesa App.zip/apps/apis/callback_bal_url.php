<?php
  $CallbackResponse = file_get_contents('php://input');
  $logFile = "BalResponse.txt";
  $log = fopen($logFile, "w");
  fwrite($log, $CallbackResponse);
  fclose($log);
?>