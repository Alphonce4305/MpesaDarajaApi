<?php 
date_default_timezone_set('Africa/Nairobi');
// function to generate access_token
function generateToken()
{
	
  $consumerKey = 'mMEqGR3xXjrWUh8GLf7Pr5NdEJAFKnvg'; //Fill with your app Consumer Key
  $consumerSecret = 'VGxB0qIAJAI3jWnp'; // Fill with your app Secret

  $headers = ['Content-Type:application/json; charset=utf8'];

  $url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

  $curl = curl_init($url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
  curl_setopt($curl, CURLOPT_HEADER, FALSE);
  curl_setopt($curl, CURLOPT_USERPWD, $consumerKey.':'.$consumerSecret);
  $result = curl_exec($curl);
  $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
  $result = json_decode($result);

  $access_token = $result->access_token;

  return $access_token;
}

// function to register validation and confirmation urls

function registerURLs()
{
	 $url = 'https://sandbox.safaricom.co.ke/mpesa/c2b/v1/registerurl';

	  $shortCode = '600423'; 

	  $confirmationUrl = 'https://diamondsoftware.co.ke/cashway/apis/confirmation_url.php';
	  $validationUrl = 'https://diamondsoftware.co.ke/cashway/apis/validation_url.php'; 

	  $curl = curl_init();
	  curl_setopt($curl, CURLOPT_URL, $url);
	  curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.generateToken())); 

	  $curl_post_data = array(
	    'ShortCode' => $shortCode,
	    'ResponseType' => 'Completed',
	    'ConfirmationURL' => $confirmationUrl,
	    'ValidationURL' => $validationUrl
	  );

	  $data_string = json_encode($curl_post_data);

	  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	  curl_setopt($curl, CURLOPT_POST, true);
	  curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
	  $curl_response = curl_exec($curl);
	 
	  return $curl_response;
}

// simulate c2b transaction

function c2b_payment()
{
    $url = 'https://sandbox.safaricom.co.ke/mpesa/c2b/v1/simulate';   
    $ShortCode  = '600423'; // Shortcode. Same as the one on register_url.php
    $amount     = '500'; // amount the client/we are paying to the paybill
    $msisdn     = '254708374149'; // phone number paying 
    $billRef    = 'cashway'; // This is anything that helps identify the specific transaction. Can be a clients ID, Account Number, Invoice amount, cart no.. etc

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.generateToken()));

    $curl_post_data = array(
           'ShortCode' => $ShortCode,
           'CommandID' => 'CustomerPayBillOnline',
           'Amount' => $amount,
           'Msisdn' => $msisdn,
           'BillRefNumber' => $billRef
    );

    $data_string = json_encode($curl_post_data);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
    $curl_response = curl_exec($curl);
   
    return $curl_response;
}


// simulate b2c transaction

function b2c_payment($pay_amount,$pay_purpose,$pay_account,$pay_desc)
{
  $b2c_url = 'https://sandbox.safaricom.co.ke/mpesa/b2c/v1/paymentrequest';
  
  $InitiatorName = 'testapi';  # Initiator / mpesa username
  $SecurityCredential = 'EiexmT4vjR0mjNt67xNjRApE5JSSdHDuzFPbkrjhQyenjBlXepJSULTHfyT1yxiMaQRdDCU5i5LA5I4JpVx/rUqWZ/zqXO/S/Njnm09F3ahtpFD7cydG///1mv4PL8zVNWkPtbNeYbEhhZer7KB1t0Z2Uwdr0JYZqS9z+IL3ZPqkoCSVqMIGlb/+bT3aeDMbMwenBOuB6TVDAHQqE2/IQCZhpZLsjX5G2Kvjt+YxPfMmwG3mtQcWa/+dYHqK3Bf+YAQLxUftJHpKTd/wqcncE+yQfeHOWC/ehGN/81cwj2eniTx7VtjkmamOWrQiRO4QIJhZcJu49ATXPxCykfQPtQ=='; 
  $CommandID = 'SalaryPayment';    # choose between SalaryPayment, BusinessPayment, PromotionPayment 
  $Amount = $pay_amount;
  $PartyA = '529729';             # shortcode 1 (Paybill no)
  $PartyB = '254'.$pay_account;   # Phone number you're sending money to
  $Remarks = $pay_purpose;      # Remarks ** can not be empty
  $QueueTimeOutURL = 'https://diamondsoftware.co.ke/cashway/apis/callback_b2c_url.php';    # your QueueTimeOutURL
  $ResultURL = 'https://diamondsoftware.co.ke/cashway/apis/callback_b2c_url.php';          # your ResultURL
  $Occasion = $pay_desc;  # Occasion

  /* Main B2C Request to the API */
  
  $b2cHeader = ['Content-Type:application/json','Authorization:Bearer '.generateToken()];
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $b2c_url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $b2cHeader); //setting custom header

  $curl_post_data = array(
    //Fill in the request parameters with valid values
    'InitiatorName' => $InitiatorName,
    'SecurityCredential' => $SecurityCredential,
    'CommandID' => $CommandID,
    'Amount' => $Amount,
    'PartyA' => $PartyA,
    'PartyB' => $PartyB,
    'Remarks' => $Remarks,
    'QueueTimeOutURL' => $QueueTimeOutURL,
    'ResultURL' => $ResultURL,
    'Occasion' => $Occasion
  );

  $data_string = json_encode($curl_post_data);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_POST, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
  $curl_response = curl_exec($curl);
  return $curl_response;
}

//Balance Query

function BalanceQuery()
{

  /* main request */
  $bal_url = 'https://sandbox.safaricom.co.ke/mpesa/accountbalance/v1/query';

  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $bal_url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.generateToken())); //setting custom header

  $curl_post_data = array(
    //Fill in the request parameters with valid values
    'Initiator'           => 'DAVID OCHIEL',                      # initiator name -> For test, use Initiator name(Shortcode 1)
    'SecurityCredential'  => 'password',                      #Base64 encoded string of the Security Credential, which is encrypted using M-Pesa public key 
    'CommandID'           => 'AccountBalance',        # Command ID, Possible value AccountBalance             
    'PartyA'              => '641322',                # ShortCode 1, or your Paybill(During Production) 
    'IdentifierType'      => '4',                      
    'Remarks'             => 'Tusonge Balance',                      # Comments- Anything can go here
    'QueueTimeOutURL'     => 'https://diamondsoftware.co.ke/cashway/apis/callback_bal_url.php',                      # URL where Timeout Response will be sent to
    'ResultURL'           => 'https://diamondsoftware.co.ke/cashway/apis/callback_bal_url.php'                       # URL where Result Response will be sent to
  );

  $data_string = json_encode($curl_post_data);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_POST, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
  $curl_response = curl_exec($curl);
 
  return $curl_response;
}


// STK pUSH MPESA PAYMENTS

function stk_push_payment($mobile,$amount)
{

  # define the variales
  # provide the following details, this part is found on your test credentials on the developer account
  $BusinessShortCode = '174379';
  $Passkey = 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919';  
  
  /*
    This are your info, for
    $PartyA should be the ACTUAL clients phone number or your phone number, format 2547********
    $AccountRefference, it maybe invoice number, account number etc on production systems, but for test just put anything
    TransactionDesc can be anything, probably a better description of or the transaction
    $Amount this is the total invoiced amount, Any amount here will be 
    actually deducted from a clients side/your test phone number once the PIN has been entered to authorize the transaction. 
    for developer/test accounts, this money will be reversed automatically by midnight.
  */
  
  $PartyA = "254".$mobile; // This is your phone number, 
  $AccountReference = 'Cashway Alphonce Test';
  $TransactionDesc = 'STK PUSH';
  $Amount = $amount;
  $BusinessShortCode = '174379';
  # Get the timestamp, format YYYYmmddhms -> 20181004151020
  $Timestamp = date('YmdHis');    
  
  # Get the base64 encoded string -> $password. The passkey is the M-PESA Public Key
  $Password = base64_encode($BusinessShortCode.$Passkey.$Timestamp);

  # header for access token
  $headers = ['Content-Type:application/json; charset=utf8'];

    # M-PESA endpoint urls
  $access_token_url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
  $initiate_url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

  # callback url
  $CallBackURL = 'https://diamondsoftware.co.ke/cashway/apis/callback_stk_url.php';  

  # header for stk push
  $stkheader = ['Content-Type:application/json','Authorization:Bearer '.generateToken()];

  # initiating the transaction
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $initiate_url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $stkheader); //setting custom header

  $curl_post_data = array(
    //Fill in the request parameters with valid values
    'BusinessShortCode' => $BusinessShortCode,
    'Password' => $Password,
    'Timestamp' => $Timestamp,
    'TransactionType' => 'CustomerPayBillOnline',
    'Amount' => $Amount,
    'PartyA' => $PartyA,
    'PartyB' => $BusinessShortCode,
    'PhoneNumber' => $PartyA,
    'CallBackURL' => $CallBackURL,
    'AccountReference' => $AccountReference,
    'TransactionDesc' => $TransactionDesc
  );

  $data_string = json_encode($curl_post_data);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_POST, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
  $curl_response = curl_exec($curl);

  return $curl_response;
}

function insert_response($jsonMpesaResponse){

//require 'dbconfig.php';

	try{
		$insert = $conn->prepare("INSERT INTO `mobile_payments`(`TransactionType`, `TransID`, `TransTime`, `TransAmount`, `BusinessShortCode`, `BillRefNumber`, `InvoiceNumber`, `OrgAccountBalance`, `ThirdPartyTransID`, `MSISDN`, `FirstName`, `MiddleName`, `LastName`) VALUES (:TransactionType, :TransID, :TransTime, :TransAmount, :BusinessShortCode, :BillRefNumber, :InvoiceNumber, :OrgAccountBalance, :ThirdPartyTransID, :MSISDN, :FirstName, :MiddleName, :LastName)");
		$insert->execute((array)($jsonMpesaResponse));

		# 1.1.2o Optional - Log the transaction to a .txt or .log file(May Expose your transactions if anyone gets the links, be careful with this. If you don't need it, comment it out or secure it)
		$Transaction = fopen('Transaction.txt', 'a');
		fwrite($Transaction, json_encode($jsonMpesaResponse));
		fclose($Transaction);
	}
	catch(PDOException $e){

		# 1.1.2b Log the error to a file. Optionally, you can set it to send a text message or an email notification during production.
		$errLog = fopen('error.txt', 'a');
		fwrite($errLog, $e->getMessage());
		fclose($errLog);

		# 1.1.2o Optional. Log the failed transaction. Remember, it has only failed to save to your database but M-PESA Transaction itself was successful. 
		$logFailedTransaction = fopen('failedTransaction.txt', 'a');
		fwrite($logFailedTransaction, json_encode($jsonMpesaResponse));
		fclose($logFailedTransaction);
	}
}


// Transaction status query

function transaction_status()
{
	
  /* making the request */
    $tstatus_url = 'https://api.safaricom.co.ke/mpesa/transactionstatus/v1/query';

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $tstatus_url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.generateToken())); //setting custom header

    $curl_post_data = array(
      //Fill in the request parameters with valid values
      'Initiator' => '',
      'SecurityCredential' => '',
      'CommandID' => 'TransactionStatusQuery',
      'TransactionID' => '',
      'PartyA' => '', // shortcode 1
      'IdentifierType' => '4',
      'ResultURL' => 'https://tusongembele.co.ke/tusonge/apis/pay_api/callback_url.php',
      'QueueTimeOutURL' => 'https://tusongembele.co.ke/tusonge/apis/pay_api/callback_status_url.php',
      'Remarks' => '',
      'Occasion' => ''
    );

    $data_string = json_encode($curl_post_data);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
    $curl_response = curl_exec($curl);
    
    return $curl_response;
}

// REVERSAL 

function reverse_payment()
{
	/* Reversal Request */
	$reversal_url = 'https://sandbox.safaricom.co.ke/mpesa/reversal/v1/request';

	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $reversal_url);
	curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.generateToken())); //setting custom header

	$curl_post_data = array(
	  //Fill in the request parameters with valid values
	  'Initiator' => '',
	  'SecurityCredential' => '',
	  'CommandID' => 'TransactionReversal',
	  'TransactionID' => '',
	  'Amount' => '',
	  'ReceiverParty' => '',
	  'RecieverIdentifierType' => '',
	  'ResultURL' => 'https://tusongembele.co.ke/tusonge/mpesa_api/callback_url.php',
	  'QueueTimeOutURL' => 'https://tusongembele.co.ke/tusonge/apis/pay_api/callback_reverse_url.php',
	  'Remarks' => 'OUT OF STOCK',
	  'Occasion' => ''
	);

	$data_string = json_encode($curl_post_data);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($curl, CURLOPT_POST, true);
	curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
	$curl_response = curl_exec($curl);
	
	return $curl_response;
}
?>