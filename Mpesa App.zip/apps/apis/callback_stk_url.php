<?php
  $CallbackResponse = file_get_contents('php://input');
  $logFile = "STKResponse.txt";
  $log = fopen($logFile, "a");
  fwrite($log, $CallbackResponse);
  fclose($log);
?>