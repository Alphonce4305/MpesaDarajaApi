<?php
  $CallbackResponse = file_get_contents('php://input');
  $logFile = "StatusResponse.txt";
  $log = fopen($logFile, "a");
  fwrite($log, $CallbackResponse);
  fclose($log);
?>