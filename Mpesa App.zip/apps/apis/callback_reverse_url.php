<?php
  $CallbackResponse = file_get_contents('php://input');
  $logFile = "ReversalResponse.txt";
  $log = fopen($logFile, "w");
  fwrite($log, $CallbackResponse);
  fclose($log);
?>