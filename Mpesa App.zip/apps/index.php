<?php 
require 'apis/functions.php';
if (isset($_POST['pay'])) {
	$mobile = substr($_POST['mobile'], -9);
	$amount = $_POST['amount'];

	if (stk_push_payment($mobile,$amount)) {
		header('Location:index.php');
	}
}
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>MPESA-API</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<link href="https://fonts.googleapis.com/css2?family=Comfortaa&family=Courgette&display=swap" rel="stylesheet">
</head>
<body>
  <div class="payments">
  	<section class="mpesa">
  		<h5 class="text-center text-success">Diamond Software Solutions Inc.<br>MPESA APIs</h5>
  		<hr>
  		<h6 class="text-center">Choose Mpesa Payment Method</h6>
  		<form class="paymentForm">
  		
  			<input type="radio" name="payment-method" value="MPESA" id="mpesa" onclick="showMpesaPayment();">
  			<label>Lipa Na Mpesa (PayBill)</label>
  			<br>
  			<input type="radio" name="payment-method" value="PAYPAL" id="paypal" onclick="showPaypalPayment();">
  			<label>Mpesa STK PUSH</label>
  		</form>
  		<div class="paycontent">
  			<div id="mpesaForm" class="bg-success">
  				<h5>LIPA NA MPESA</h5>
  				<p id="mpesaProcedure">1. GO M-PESA <br> 2. SELECT LIPA NA M-PESA , <br> 3. SELECT PAYBILL ,<br> 4. ENTER BUSINESS NO. 641322,<br> 5. ENTER ACCOUNT NO. 0740216370 , <br> 6. ENTER PIN AND SEND</p>

			<div class="card" id="verifyForm">
				<div class="card-header" style="color: #000;">VERIFICATION</div>
				<div class="card-body">
					<form action="" method="post" >
			  			<label id="verifyLabel">Enter Mpesa Code </label>
			  			<br>
			  			<input type="text" name="verify" placeholder="E.g OHY666IJ" required="" class="form-control" id="verifyText">
			  			<br>
			  			<input type="submit" name="confirm" value="Submit" class="btn btn-info btn-sm btn-flat" onclick="confirmCode();" id="verifyBtn">
						<p id="confirmCode">Payment was successful...</p>
			  		</form>
				</div>
			</div>
							
			<button class="btn btn-info btn-sm btn-flat" id="nextBtn" onclick="proceedNext();">Proceed ...</button>
  			</div>
	
	<div class="card" id="paypalForm">
		<div class="card-header bg-info">MPESA STK PUSH</div>
		<div class="card-body">
			<form action="?" method="post">
  				<label>Enter Mpesa No.</label>
  				<br>
  				<input type="text" name="mobile" placeholder="E.g 073229000" min="0" class="form-control" required=""><br>
  				<label>Enter Amount.</label>
  				<br>
  				<input type="number" name="amount" placeholder="E.g 500" min="0" class="form-control" required="">
  				<br>
  				<input type="submit" name="pay" value="Submit" class="btn btn-primary btn-flat btn-sm">
  			</form>
		</div>
	</div>
 </div>
 <small class="text-center">&copy; 2020 Designed by <a href="https/alphonce.iluos.co.ke">Diamond Software Solutions Inc.</a></small>
  	</section>
  </div>
</body>
</html>

<style type="text/css">
	html,body{
		font-size: 18px;
		font-family: Comfortaa;
		margin: none;
		background: inherit;
	}
	.payments{
		width: 50%;
		display: block;
	}
	.payments > .mpesa{
		display: block;
		width: 100%;
		margin-top: 10%;
		margin-left: 45%;
		border: 1px solid black;
		padding: 20px;
		box-shadow: 1px 2px 4px 1px black;
		z-index: 99;
		height: auto;
	}
	.text-center{
		text-align: center;
	}
	.paymentForm{
		text-align: left;
		font-family: Comfortaa;
		font-size: 15px;
	}
	.paycontent{
		background-color: #fff;
		width: auto;
		height: auto;
		opacity: 0.9;
		color: #000;
		padding: 15px;
		border-radius: 5px;
	}
	.paycontent > form{
		font-size: 18px;
		text-align: left;
		margin: 10px;
	}
	.paycontent > form > .input-field{
		font-size: 12px;
		text-align: left;
		margin: 10px;
		height: 20px;
		padding: 4px;
	}
	.paycontent > form > .input-submit{
		font-size: 18px;
		text-align: left;
		margin: 10px;
		height: 30px;
		background-color:blue;
		border-radius: 5px;
		cursor:pointer;
	}
	#mpesaForm {
		display: none;
		border-radius: 5px;
		padding: 15px;
		color: #fff;
	}
	#verifyForm{
		display: none;
	}
	#paypalForm {
		display: none;
		border-radius: 5px;
		padding: 15px;
	}
	#confirmCode{
		display: none;
		color: green;
		font-size: auto;
		text-align: center;
	}
</style>

<script>
	var displayPaypal = document.getElementById('paypalForm');
	var displayMpesa = document.getElementById('mpesaForm');
	var verify = document.getElementById('verifyForm');
	var  mpesaProcedure = document.getElementById('mpesaProcedure');
	var  nextBtn = document.getElementById('nextBtn');
	function showMpesaPayment() {
		displayMpesa.style.display="block";
		displayPaypal.style.display="none";
	}
	function showPaypalPayment() {
			displayPaypal.style.display="block";
			displayMpesa.style.display="none";
		}
	function proceedNext() {
		verify.style.display="block";
		verify.style.transition="2s ease";
		mpesaProcedure.style.display="none";
		nextBtn.style.display="none";
	}
	function confirmCode() {
			document.getElementById('verifyText').style.display="none";
			document.getElementById('verifyLabel').style.display="none";
			document.getElementById('verifyBtn').style.display="none";
			document.getElementById('confirmCode').style.display="block";
		}	
</script>